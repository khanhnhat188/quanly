<?php
$departments = DepartmentController::getDepartment($connect);
?>
<div class="container">
    <a href="?action=department&query=add" class="btn btn-primary mb-3"> Add Department</a>
    <a href="?employee=add" class="btn btn-primary mb-3"> Add Employee</a>
    <table class="table table-striped">
        <thead>
            <tr>
                <th>ID</th>
                <th>Phòng ban</th>
                <th>Modify</th>
                <th>Remove</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($departments as $row): ?>
                <tr>
                    <td><?php echo $row['id']; ?></td>
                    <td><?php echo $row['name']; ?></td>
                    <td><a href="?department=edit&id=<?php echo $row['id']; ?>" class="btn btn-warning btn-sm">Edit</a></td>
                    <td><a href="?department=delete&id=<?php echo $row['id']; ?>" class="btn btn-danger btn-sm">Delete</a></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
