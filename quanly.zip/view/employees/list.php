<?php
$employees = EmployeeController::getEmployee($connect);
?>

<div class="container">

    <table class="table table-striped">
        <thead>
            <tr>
                <th>ID</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Birthday</th>
                <th>Gender</th>
                <th>Phone</th>
                <th>Email</th>
                <th>City</th>
                <th>District</th>
                <th>Ward</th>
                <th>Full Address</th>
                <th>Modify</th>
                <th>Remove</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($employees as $row): ?>
                <tr>
                    <td><?php echo $row['id']; ?></td>
                    <td><?php echo $row['first_name']; ?></td>
                    <td><?php echo $row['last_name']; ?></td>
                    <td><?php echo $row['birthday']; ?></td>
                    <td><?php echo $row['gender']; ?></td>
                    <td><?php echo $row['phone']; ?></td>
                    <td><?php echo $row['email']; ?></td>
                    <td><?php echo $row['city']; ?></td>
                    <td><?php echo $row['district']; ?></td>
                    <td><?php echo $row['ward']; ?></td>
                    <td><?php echo $row['full_address']; ?></td>
                    <td><a href="?page=edit&id=<?php echo $row['id']; ?>" class="btn btn-warning btn-sm">Edit</a></td>
                    <td><a href="?page=delete&id=<?php echo $row['id']; ?>" class="btn btn-danger btn-sm">Delete</a></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

