<?php
require "config/connect.php";
require "controller/DepartmentController.php";
require "controller/EmployeeController.php";
require "model/employees.php";
include "model/department.php";
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="./css/style.css">
    <title>Posts</title>

</head>

<body>
<?php
    
    if(isset($_GET['action']) && isset($_GET['query'])){
        $tam = $_GET['action'];
        $query = $_GET['query'];
    }else{
        $tam = '';
        $query = '';
    }
    if($tam == 'department' && $query == 'add'){
        include './view/department/add.php';
    }elseif($tam == 'department' && $query == 'list'){
        include './view/department/list.php';
    }elseif($tam == 'department' && $query == 'edit'){
        include './view/department/edit.php';
    }elseif($tam == 'employee' && $query == 'add'){
        include './view/employees/add.php';
    }elseif($tam == 'employee' && $query == 'list'){
        include './view/employees/list.php';
    }else{
        include 'home.php';
    }
    
?>
</body>

</html>